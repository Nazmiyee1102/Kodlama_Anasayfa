﻿using System;
using System.Collections.Generic;
using KodlamaioAnasayfa.Entities;

namespace Kodlamaio
{
    class Program
    {
        static void Main(string[] args)
        {
            Use();

            
        }

        private static void Use()
        {
            
        }
    }
}
