﻿using System;
using System.Collections.Specialized;
using Anasayfa.Entities;

namespace Anasayfa
{
    class Program
    {
        static void Main(string[] args)
        {
            Choise();
        }

        private static void Choise()
        {
            throw new NotImplementedException();
        }
    }
}
