﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Anasayfa.Entities
{
    public class Instructor
    {
        public int Choise()
        {
            Console.WriteLine("Eğitmeninizi seçiniz: ");

            int InstructorId = int.Parse((Console.ReadLine()));

            switch (InstructorId)
            {
                case 1:
                    Console.WriteLine("Tümü: ");
                    Console.WriteLine("1- Senior Yazılım Geliştirici Yetiştirme Kampı (.NET)");
                    Console.WriteLine("2- Yazılım Geliştirici Yetiştirme Kampı (C# + ANGULAR)");
                    Console.WriteLine("3- Yazılım Geliştirici Yetiştirme Kampı - Python & Selenium");
                    Console.WriteLine("4- (2023) Yazılım Geliştirici Yetiştirme Kampı");
                    Console.WriteLine("5- (2022) Yazılım Geliştirici Yetiştirme Kampı - JAVA");
                    Console.WriteLine("6- Yazılım Geliştirici Yetiştirme Kampı (JavaScript)");
                    Console.WriteLine("7- Yazılım Geliştirici Yetiştirme Kampı (JAVA + REACT)");
                    Console.WriteLine("8- Programlamaya Giriş için Temel Kurs");
                    break;
                case 2:
                    Console.WriteLine("Engin Demiroğ: ");
                    Console.WriteLine("1- Senior Yazılım Geliştirici Yetiştirme Kampı (.NET)");
                    Console.WriteLine("2- Yazılım Geliştirici Yetiştirme Kampı (C# + ANGULAR)");
                    Console.WriteLine("3- Yazılım Geliştirici Yetiştirme Kampı - Python & Selenium");
                    Console.WriteLine("4- (2023) Yazılım Geliştirici Yetiştirme Kampı");
                    Console.WriteLine("5- (2022) Yazılım Geliştirici Yetiştirme Kampı - JAVA");
                    Console.WriteLine("6- Yazılım Geliştirici Yetiştirme Kampı (JavaScript)");
                    Console.WriteLine("7- Geliştirici Yetiştirme Kampı (JAVA + REACT)");
                    break;
                case 3:
                    Console.WriteLine("Halit Enes Kalaycı: ");
                    Console.WriteLine("1- Programlamaya Giriş için Temel Kurs");
                    break;
                default:
                    Console.WriteLine("Böyle bir eğitmen bulunamadı.");
                    break;
            }

        }
    }

   
}
